
import React, { useEffect, useState } from 'react';

import {
  View,
  Text,
  Button,
  StyleSheet,
  Alert,
  Platform
} from 'react-native';

import * as Notifications from 'expo-notifications';
import * as Device from 'expo-device';
import Constants from 'expo-constants';

// Configuración de notificaciones nativas
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: false,
  }),
});

// Función para mostrar alertas
function showAlert(title, message) {
  if (Platform.OS === 'web') {
    window.alert(title + '\n' + message);
  } else {
    Alert.alert(title, message);
  }
}

// Solicitar permisos
async function registerForPushNotificationsAsync() {
  try {

    // PERMISOS EN WEB
    if (Platform.OS === 'web') {

      if (!('Notification' in window)) {
        return { status: 'unavailable', token: null };
      }

      let status = Notification.permission;

      if (status === 'default') {
        status = await Notification.requestPermission();
      }

      if (status !== 'granted') {
        showAlert(
          'Permiso denegado',
          'Activa las notificaciones en tu navegador.'
        );
      }

      return { status, token: null };
    }

    // PERMISOS EN ANDROID E IOS
    if (!Device.isDevice) {
      return { status: 'unavailable', token: null };
    }

    if (Platform.OS === 'android') {
      await Notifications.setNotificationChannelAsync('default', {
        name: 'Notificaciones',
        importance: Notifications.AndroidImportance.MAX,
        vibrationPattern: [0, 250, 250, 250],
      });
    }

    const { status: existingStatus } =
      await Notifications.getPermissionsAsync();

    let finalStatus = existingStatus;

    if (existingStatus !== 'granted') {
      const { status } =
        await Notifications.requestPermissionsAsync();

      finalStatus = status;
    }

    if (finalStatus !== 'granted') {
      showAlert('Permiso denegado', 'Activa las notificaciones.');
      return { status: finalStatus, token: null };
    }

    const projectId =
      Constants.expoConfig?.extra?.eas?.projectId;

    const response = await Notifications.getExpoPushTokenAsync(
      projectId ? { projectId } : undefined
    );

    return {
      status: finalStatus,
      token: response.data,
    };

  } catch (error) {
    console.log(error);
    return { status: 'error', token: null };
  }
}

// Programar notificación
async function scheduleNotification() {

  const notificationDate = new Date(Date.now() + 5000);

  // NOTIFICACIÓN PARA PC
  if (Platform.OS === 'web') {

    if (!('Notification' in window) ||
        Notification.permission !== 'granted') {
      throw new Error('No tienes permiso para notificaciones.');
    }

    setTimeout(() => {
      new Notification('¡Notificación!', {
        body: 'Esta es una prueba de notificación local.',
        icon: '/favicon.ico',
      });
    }, 5000);

    return notificationDate;
  }

  // NOTIFICACIÓN PARA CELULAR
  await Notifications.scheduleNotificationAsync({
    content: {
      title: '¡Notificación!',
      body: 'Esta es una prueba de notificación local.',
      sound: true,
    },
    trigger: {
      type: Notifications.SchedulableTriggerInputTypes.TIME_INTERVAL,
      seconds: 5,
    },
  });

  return notificationDate;
}

// COMPONENTE PRINCIPAL
export default function App() {

  const [token, setToken] = useState(null);

  const [permissionStatus, setPermissionStatus] =
    useState('Verificando...');

  const [nextNotification, setNextNotification] =
    useState(null);

  // Solicitar permisos al iniciar
  const requestPermission = async () => {
    const result = await registerForPushNotificationsAsync();

    setPermissionStatus(result.status);
    setToken(result.token);
  };

  useEffect(() => {
    requestPermission();
  }, []);

  // Programar notificación
  const handleNotification = async () => {
    try {
      const date = await scheduleNotification();

      setNextNotification(date.toLocaleTimeString());

      showAlert(
        'Notificación programada',
        'Recibirás una notificación en 5 segundos.'
      );

    } catch (error) {
      showAlert('Error', error.message);
    }
  };

  return (
    <View style={styles.container}>

      <Text style={styles.title}>
        Sistema de Notificaciones
      </Text>

      <Text style={styles.subtitle}>
        React Native + Expo
      </Text>

      <Text style={styles.label}>
        Estado del permiso:
      </Text>

      <Text style={[
        styles.status,
        {
          color: permissionStatus === 'granted'
            ? 'green'
            : permissionStatus === 'Verificando...'
            ? 'orange'
            : 'red'
        }
      ]}>
        {permissionStatus === 'granted'
          ? 'Permiso concedido'
          : permissionStatus === 'Verificando...'
          ? 'Verificando permiso...'
          : 'Permiso denegado o no disponible'}
      </Text>

      <View style={styles.card}>
        <Text style={styles.label}>
          Token del dispositivo:
        </Text>

        <Text selectable style={styles.token}>
          {token ||
            (Platform.OS === 'web'
              ? 'El token Expo se obtiene desde un dispositivo físico.'
              : 'Token no disponible')}
        </Text>
      </View>

      <View style={styles.button}>
        <Button
          title="Solicitar permiso nuevamente"
          onPress={requestPermission}
          color="#2563eb"
        />
      </View>

      <View style={styles.button}>
        <Button
          title="Programar notificación"
          onPress={handleNotification}
          color="#16a34a"
          disabled={permissionStatus !== 'granted'}
        />
      </View>

      <View style={styles.card}>
        <Text style={styles.label}>
          Próxima notificación:
        </Text>

        <Text style={styles.time}>
          {nextNotification || 'Ninguna programada'}
        </Text>
      </View>

    </View>
  );
}

// ESTILOS
const styles = StyleSheet.create({

  container: {
    flex: 1,
    backgroundColor: '#f1f5f9',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },

  title: {
    fontSize: 25,
    fontWeight: 'bold',
    color: '#1e293b',
    textAlign: 'center',
  },

  subtitle: {
    fontSize: 16,
    color: '#64748b',
    marginBottom: 30,
  },

  label: {
    fontSize: 16,
    fontWeight: 'bold',
    marginBottom: 10,
    color: '#334155',
  },

  status: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 25,
  },

  card: {
    backgroundColor: 'white',
    width: '100%',
    padding: 15,
    borderRadius: 12,
    marginBottom: 20,
  },

  token: {
    fontSize: 12,
    color: '#475569',
  },

  button: {
    width: '100%',
    marginBottom: 15,
  },

  time: {
    fontSize: 17,
    color: '#16a34a',
    fontWeight: 'bold',
  },

});
